MY ONLINE STORE — বাংলা নির্দেশিকা

১) ZIP ফাইলটি Extract করুন।
২) index.html ফাইলটি GitHub repository-তে Upload files দিয়ে আপলোড করুন।
৩) Commit changes চাপুন।

নিজের তথ্য বদলাতে index.html ফাইলের নিচের দিকে:
- WHATSAPP_NUMBER-এ দেশের কোডসহ নিজের WhatsApp নম্বর দিন (বাংলাদেশ: 8801...; + বা শুরুর 0 নয়)।
- MESSENGER_PAGE-এ Facebook Page username দিন।
- PRODUCTS তালিকায় নিজের পণ্যের নাম, ক্যাটাগরি, দাম, বিবরণ, emoji এবং চাইলে image URL দিন।

গুরুত্বপূর্ণ:
এটি প্রাথমিক static catalogue। এতে এখনো admin dashboard, payment checkout, database বা visitor order tracking নেই। পণ্য আপডেট করতে index.html পরিবর্তন করে GitHub-এ আবার commit করতে হবে. Placeholder যোগাযোগের তথ্য বদলানো ছাড়া অর্ডার বাটন সঠিকভাবে কাজ করবে না.
